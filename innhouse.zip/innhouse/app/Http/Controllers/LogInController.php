<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\house;
use App\Log_in;

class LogInController extends Controller
{   
    public function showLogin(Request $request){

        return view('login-page');       
    }

    public function doLogin(Request $request){

    $user_name = $request->input('user_name');
    $password = $request->input('password');

    $checklogin = DB::table('log_ins')->where(['user_name'=>$user_name,'password'=>$password])->get();
    if(count($checklogin) > 0){
        return view('home-page');
    }
    else{
        return view('login-page');
    }

   }

   public function saveUser(Request $request)
   {
        $name = $request->name;
        $user_name = $request->user_name;
        $email = $request->email;
        $age = $request->age;
        $password = $request->password;

        $log_in = new Log_in;
        $log_in->name = $name;
        $log_in->user_name = $user_name;
        $log_in->email = $email;
        $log_in->age = $age;
        $log_in->password = $password;
        $log_in->save();

        return redirect('/login');
   }

   public function showRent(Request $request){

        return view('rental');

   }

    public function showRent2(Request $request){

        return view('rental-2');

   }

   public function showAbout(Request $request){

        return view('aboutus');

   }
}
