<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
//home
Route::get('/','AppController@showIndex');

//login
Route::get('/login', function () {
    return view('login-page');
});
Route::post('/loginprocess','LogInController@doLogin');

//Sign-up
Route::get('/signup',function() {
	return view('signup-page');
});

Route::post('/save-user','LogInController@saveUser');

Route::get('/rent','LogInController@showRent');

Route::get('/rent2','LogInController@showRent2');

Route::get('/about','LogInController@showAbout');