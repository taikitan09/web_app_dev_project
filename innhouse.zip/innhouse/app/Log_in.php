<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Log_in extends Model
{
    //
}
