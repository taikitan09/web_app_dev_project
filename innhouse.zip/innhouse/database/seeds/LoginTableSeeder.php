<?php

use Illuminate\Database\Seeder;
use App\Log_in;
class LoginTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('log_ins')->delete();
        Log_in::create(array(
        'name'     => 'Chris Sevilleja',
        'user_name' => 'sevilayha',
        'email'    => 'chris@scotch.io',
        'age'	   => '18',
        'password' => Hash::make('awesome'),
    ));

    }
}
