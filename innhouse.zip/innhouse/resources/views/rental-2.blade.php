@extends('layout.myapp')

@section('content')

<h1>House for Rent</h1><br>

	<div class="row">
  	<div class="col-sm-6 col-md-4">
    	<div class="thumbnail">
    	  <img src="/house/7/1.jpg" alt="#">
      		<div class="caption">
        	<h3>Rent</h3>
        	<p>...</p>
        	<p><a href="#" class="btn btn-primary" role="button">Button</a></p>
            </div>
        </div>
    </div>
	
  	<div class="col-sm-6 col-md-4">
    	<div class="thumbnail">
    	  <img src="/house/8/1.jpg" alt="#">
      		<div class="caption">
        	<h3>Rent</h3>
        	<p>...</p>
        	<p><a href="#" class="btn btn-primary" role="button">Button</a></p>
            </div>
        </div>
    </div>
	
  	<div class="col-sm-6 col-md-4">
    	<div class="thumbnail">
    	  <img src="/house/9/1.jpg" alt="#">
      		<div class="caption">
        	<h3>Rent</h3>
        	<p>...</p>
        	<p><a href="#" class="btn btn-primary" role="button">Button</a></p>
            </div>
        </div>
    </div>
	</div>
	<div class="row">
  	<div class="col-sm-6 col-md-4">
    	<div class="thumbnail">
    	  <img src="/house/10/1.jpg" alt="#">
      		<div class="caption">
        	<h3>Rent</h3>
        	<p>...</p>
        	<p><a href="#" class="btn btn-primary" role="button">Button</a></p>
            </div>
        </div>
    </div>
	
  	<div class="col-sm-6 col-md-4">
    	<div class="thumbnail">
    	  <img src="/house/11/1.jpg" alt="#">
      		<div class="caption">
        	<h3>Rent</h3>
        	<p>...</p>
        	<p><a href="#" class="btn btn-primary" role="button">Button</a></p>
            </div>
        </div>
    </div>
	
  	<div class="col-sm-6 col-md-4">
    	<div class="thumbnail">
    	  <img src="/house/12/1.png" alt="#">
      		<div class="caption">
        	<h3>Rent</h3>
        	<p>...</p>
        	<p><a href="#" class="btn btn-primary" role="button">Button</a></p>
            </div>
        </div>
    </div>
	</div>
<center>
<ul class="pagination">
  <li class="previous"><a href="/rent">1</a></li>
  <li class="next"><a href="/rent2">2</a></li>
</ul>
</center>
@endsection