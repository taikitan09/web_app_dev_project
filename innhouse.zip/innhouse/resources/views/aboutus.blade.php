@extends('layout.myapp')

@section('content')

<div class="page-header">
  <h1>About Us</h1>
</div>
<img src="/pictures/img.jpeg" class="img-fluid" alt="Responsive image">

<br><br>

<div class="card">
  <div class="card-block">
    
    <p class="card-text text-md-left">Inn House is a rental website for travelers, vacationist, that provide rental home in specific period of time and duration of stay. Inn House also provides quality house that is budget friendly to the customer and they can choose what will suit for their taste. </p>

    <p class="card-text text-md-left">Inn House is a website also for home owners that are wanting to rent there place while they are out of town or they have second house it is a great opportunity for home owners to have income.</p>
    
  </div>
</div>
@endsection