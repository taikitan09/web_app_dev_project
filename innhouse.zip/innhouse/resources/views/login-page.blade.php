@extends('layout.signapp')

@section('content')

   <div class="container">
   <div class="col-md-9 col-md-offset-4">
	<h1>Log In</h1>

	<form method="POST" action="/loginprocess">
	{{ csrf_field() }}
		<div class="form-group col-md-4">
			Username: <input type="text" name="user_name" class="form-control"><br>
			Password: <input type="password" name="password" class="form-control"><br>
			<button type="submit" class="btn btn-info">Log In</button>
		</div>
	</form>

   </div>
  </div>

@endsection