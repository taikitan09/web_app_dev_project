@extends('layout.login')


@section('content')
<div class="container">
	<div class="col-md-9 col-md-offset-4">
	<h1>Sign Up</h1>
	<form action="/save-user" method="post">
	{{ csrf_field() }}
	
		<div class="form-group col-md-4">
			Name: <input type="text" name="name" class="form-control" placeholder="Name"><br>
			Username: <input type="text" name="user_name" class="form-control" placeholder="user name"><br>
			E-mail: <input type="email" name="email" class="form-control" placeholder="E-mail"><br>
			Age: <input type="number" name="age" class="form-control" placeholder="age"><br>
			Password: <input type="password" name="password" class="form-control" placeholder="password"><br>	
			<button type="submit" class="btn btn-primary">Save</button>
			<button type="reset" class="btn btn-danger">Reset</button>
		</div>	
    </form>
    </div>
</div>	
@endsection