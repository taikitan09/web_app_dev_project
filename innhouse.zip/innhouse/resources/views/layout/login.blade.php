<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1">
	<title>Sign Up</title>
	<link rel="stylesheet" type="text/css" href="/libraries/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="/libraries/bootstrap/css/bootstrap-theme.css">
  <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body background="/pictures/back.jpg">
<div class="container">
 <nav class="navbar navbar-light style="background-color: #e3f2fd;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="/">InnHouse</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/">Home</a></li>
      <li><a href="/rent">Rents</a></li> 
      <li><a href="/about">About us</a></li> 
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="/signup"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="/login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li>
      <div class="searchbar">
        <form class="form-inline">
          <input class="form-control mr-sm-2 input-sm" type="text" placeholder="Search">
          <button class="btn btn-info my-2 my-sm-0 btn-sm" type="submit">Search</button>
        </form>
      </div>  
      </li>
    </ul>
  </div>
 </nav>
</div>
 <div class="container">

		@yield('content')

 </div>
 <br>
 <center>
   all rights reserved innhouse 2018
 </center>
 <br>
</body>
</html>