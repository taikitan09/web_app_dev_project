@extends('layout.myapp')

@section('content')

<div class="jumbotron jumbotron-fluid">
  <div class="container" background="/pictures/beautiful-wallpaper-39.jpg">
    <h1 class="display-3">Welcome</h1>
    <p class="lead">Travel around the world and rent a affordable house any where you go.</p>
  </div>
</div>


@endsection